---
name: Hacktoberfest Feature
about: For new Feature ideas during Hacktoberfest 2020
title: "[Summary of feature here.]"
labels: enhancement, hacktoberfest
assignees: ''

---

# Goal

- Write a clear and concise summary of the feature you would like to implement.

# Details

- Write a detailed description of the feature you would like to implement. Include screenshots and/or whatever details you believe would help to create this feature.
