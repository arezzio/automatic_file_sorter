---
name: Feature request
about: Suggest an idea for this project
title: "[Summary of feature here.]"
labels: enhancement
assignees: ''

---

# Goal

- Write a clear and concise summary of the feature you would like to implement.

# Details

- Write a detailed description of the feature you would like to implement. Include screenshots and/or whatever details you believe would help to create this feature.
